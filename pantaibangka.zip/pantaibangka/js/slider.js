let currentIndex = 0;

function showSlide(index) {
    const carousel = document.getElementById('carousel');
    const slides = document.querySelectorAll('.carousel-item');
    if (index >= slides.length) currentIndex = 0;
    else if (index < 0) currentIndex = slides.length - 1;
    else currentIndex = index;

    const offset = -currentIndex * 100;
    carousel.style.transform = `translateX(${offset}%)`;
}

function nextSlide() {
    showSlide(currentIndex + 1);
}

function prevSlide() {
    showSlide(currentIndex - 1);
}

setInterval(nextSlide, 3000); // Pindah otomatis setiap 3 detik

// Script untuk menu toggle
const menuToggle = document.getElementById('menu-toggle');
const menu = document.querySelector('.menu');

menuToggle.addEventListener('click', () => {
    // Toggle class 'active' untuk menu
    menu.classList.toggle('active');
});

function toggleAnswer(index) {
    const answer = document.getElementById('answer-' + index);
    if (answer.classList.contains('active')) {
        answer.classList.remove('active');
    } else {
        // Tutup semua jawaban lainnya (opsional)
        const allAnswers = document.querySelectorAll('.faq-answer');
        allAnswers.forEach((ans) => ans.classList.remove('active'));

        // Buka jawaban yang dipilih
        answer.classList.add('active');
    }
}

function checkAllDestinations() {
    var checkboxes = document.querySelectorAll('input[name="destinasi[]"]');
    checkboxes.forEach(function(checkbox) {
        checkbox.checked = true;
    });
}