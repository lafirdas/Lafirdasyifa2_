Website ini merupakan website yang menginformasi seputar Kota Solo. Di dalam website ini terdapat 3 halaman yaitu Home, Sejarah, dan Feedback
Pada website ini terdapat informasi tentang sejarah kota solo, dan wisata yang harus dikunjungi ketiga mendatangi kota solo.
Di halmaan feedback terdapat form, yang berfungsi agar pengunjung website dapat memberikan feedback kepada pembuat website.